<?php
    session_start();
    error_reporting(E_ALL);
    include('connection.php');

    if (isset($_POST['sub'])) {
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $password = mysqli_real_escape_string($con, $_POST['password']); // Consider using password_hash() and password_verify()

        $query = mysqli_query($con, "SELECT * FROM user WHERE email='$email' AND password='$password'");
        if (!$query) {
            die('Query Error: ' . mysqli_error($con));
        }
        
        $result = mysqli_fetch_assoc($query);
        
        if ($result) {
            // User exists, create session variables and redirect to welcome.php
            $_SESSION['uid'] = $result['id'];
            $_SESSION['un'] = $result['name'];
            $_SESSION['email'] = $result['email'];
            $_SESSION['phone'] = $result['phone'];
            header("Location: welcome.php");
            exit();
        } else {
            echo "<script>alert('Invalid email or password. Please try again.');</script>";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Zipper - Responsive HTML Template</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400">
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/tooplate-style.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
</head>
<body>
    <section class="tm-section tm-section-home tm-flex-center" id="home" style="min-height: 800px;">
        <div class="tm-hero">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="text-uppercase tm-hero-title">Sign In Page</h1>
                    <p class="tm-hero-subtitle">Login To Get Access to Special Cafe®!</p>
                </div>
                <center>
                    <?php 
                        if(!isset($_SESSION['uid'])){
                    ?>
                    <div class="tm-bg-black-translucent" style="padding:5px;color:white;">
                        <h3>Login</h3>
                        <form method="post" class="tm-contact-form">
                            <input type="email" name="email" placeholder="Email" class="form-control2" required /><br/><br/>
                            <input type="password" name="password" placeholder="Password" class="form-control2" required /><br/><br/>
                            <span>Don't Have an Account? Create One!</span><a href="./register.php">Sign Up Here!</a><br/>
                            <div class="col-12">
                                <input type="submit" name="sub" value="LOGIN" class="submit_button btn btn-primary mt-2" />
                            </div>
                        </form>
                    </div>   
                    <?php
                        } else {
                            echo "<h3 style='padding:5px;color:white;'>Welcome ".$_SESSION['un']."</h3><br/>";
                            echo "<h3 style='padding:5px;color:white;'><a href='logout.php'>Logout</a></h3>";
                        }
                    ?>
                </center>
            </div>                    
        </div>             
    </section>
    <script src="js/jquery-1.11.3.min.js"></script>
    <script src="https://www.atlasestateagents.co.uk/javascript/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.singlePageNav.min.js"></script>
</body>
</html>