<?php
    echo "There is nothing you got trolled 🤣🤣🤣";
?>
